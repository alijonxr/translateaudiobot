from translate import Translator
translator = Translator(to_lang="uz")
print(translator.translate("this is a pen"))